<!-- General JS Scripts -->
<script src="{{ asset('admin_area/assets/js/app.min.js') }}"></script>
  <!-- JS Libraies -->
  <script src="{{ asset('admin_area/assets/bundles/izitoast/js/iziToast.min.js') }}"></script>
  <script src="{{ asset('admin_area/assets/bundles/apexcharts/apexcharts.min.js') }}"></script>
  <!-- Page Specific JS File -->
  <script src="{{ asset('admin_area/assets/js/page/index.js') }}"></script>
  <script src="{{ asset('admin_area/assets/js/kinzi.print.min.js') }}"></script>
  <!-- Template JS File -->
  <script src="{{ asset('admin_area/assets/js/scripts.js') }}"></script>
  <!-- Custom JS File -->
  <script src="{{ asset('admin_area/assets/js/custom.js') }}"></script>
  