@extends('admin.pages.master')
@section('title')
    New Orders
@endsection

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Pending Orders ({{ \App\Models\Order::countPendingOrders() }})</h4>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer Name</th>
                                        <th>Total Amount</th>
                                        <th>Payment Type</th>
                                        <th>Email </th>
                                        <th>Phone</th>
                                        <th>Order Placed</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach ($pending_orders as $order)
                                        <tr  @if ($order->seenByAdmin == 0) class="text-muted" @endif>
                                            <td>{{ $order->id }}</td>
                                            <td>{{ $order->fullName }}</td>
                                            <td>{{ $order->totalPrice }}</td>
                                            <td>
                                                @if ($order->paymentType == "cash")
                                                   Cash on delivery
                                                   @elseif($order->paymentType == "card")
                                                   Stripe Payment ({{ $order->paymentId }})
                                                   @elseif($order->paymentType == "paypal")
                                                   Paypal Payment ({{ $order->paymentId }})
                                                @endif
                                            </td>
                                            <td>{{ $order->email }}</td>
                                            <td>{{ $order->phone }}</td>
                                            <td>{{ $order->created_at->diffForHumans() }}</td>
                                            <td>
                                                <a href="#" class="btn btn-sm btn-primary">View Details</a>
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>

                        <div class="row justify-content-center">
                            {{ $pending_orders->links('pagination::bootstrap-4') }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection