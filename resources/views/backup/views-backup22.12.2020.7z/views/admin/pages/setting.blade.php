@extends('admin.pages.master')
<link rel="stylesheet" href="{{ asset('admin_area/assets/bundles/izitoast/css/iziToast.min.css') }}">

@section('title')
    Settings
@endsection

@section('content')
    @include('admin.components.alert')
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <h4>Settings</h4>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <div class="control-label">Open/Close Store</div>
                        <label class="custom-switch mt-2" title="@if($status->online_purchase == 1) Disable @else Enable @endif">
                          <input id="toogleStore" type="checkbox" name="custom-switch-checkbox" class="custom-switch-input" @if($status->online_purchase == 1) checked @endif>
                          <span class="custom-switch-indicator"></span>
                          <span class="custom-switch-description">Online Store</span>
                        </label>
                      </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('customJs')
<script src="{{ asset('admin_area/assets/bundles/izitoast/js/iziToast.min.js') }}"></script>
<script>
    $('#toogleStore').on('change', function()
    {
        var status = null;
        if($(this).is(':checked'))
        {
            status = "on";
        }
        else{
            status = "off";
        }

        $.ajax({
            type:'POST',
            url:'{{ route('admin.setting') }}',
            dataType:'json',
            data:{
                "_token": "{{ csrf_token() }}",
                "status": status
            },
            success:function(resp){
                if(resp.code == 0)
                {
                    if(resp.status == 1)
                    {
                        $('#toogleStore').parent().prop('title', "Disable");
                            iziToast.success({
                            title: 'Enabled',
                            message: 'Store is Open ',
                            position: 'topRight'
                        });
                    }
                    else if(resp.status == 0)
                    {
                        $('#toogleStore').parent().prop('title', "Enable");
                        iziToast.warning({
                            title: 'Disabled',
                            message: 'Store is Closed ',
                            position: 'topRight'
                        });
                    }
                }
            },
            error:function(err){
                console.error(err.responseText);
            }
        })
        
    })
</script>
@endsection
