@php
use App\Cart;
@endphp
@extends('main.components.master')
@section('customCss')
  <link rel="stylesheet" media="screen" href="{{ asset('css/chosen.css') }}" />
  <link rel="stylesheet" media="screen" href="{{ asset('css/flatpickr.min.css') }}" />
@endsection

@section('main')
    <!-- Page content-->
    <form class="cs-sidebar-enabled cs-sidebar-right needs-validation" novalidate autocomplete="off" onsubmit="isInvalid(event)">
        <div class="container">
            <div class="row">
                <!-- Content-->
                <div class="col-lg-8 cs-content py-4">
                    <nav aria-label="breadcrumb">
                        <ol class="py-1 my-2 breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item"><a href="shop-ls.html">Shop</a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Checkout</li>
                        </ol>
                    </nav>
                    <h1 class="mb-3 pb-4">Checkout</h1>
                    <div class="alert alert-info font-size-md mb-5" role="alert"><i
                            class="fe-alert-circle font-size-xl mt-n1 mr-3"></i>Have a coupon code? <a href='#modal-coupon'
                            data-toggle='modal' class='alert-link'>Click here to enter your code</a></div>
                    <h2 class="h3 pb-3">Billing details</h2>
                    <div class="row mb-4">
                        <div class="col-sm-6 form-group">
                            <label class="form-label" for="ch-fn">First name<sup class="text-danger ml-1">*</sup></label>
                            <input class="form-control" type="text" id="ch-fn" required>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form-label" for="ch-ln">Last names<sup class="text-danger ml-1">*</sup></label>
                            <input class="form-control" type="text" id="ch-ln" required>
                        </div>
                        <div class="col-12 form-group">
                            <label class="form-label" for="ch-company">Company name</label>
                            <input class="form-control" type="text" id="ch-company">
                        </div>
                        <div class="col-12 form-group">
                            <label class="form-label" for="ch-city">City<sup class="text-danger ml-1">*</sup></label>
                            <select class="form-control custom-select chosen" id="ch-city" required>
                                <option value="" selected disabled hidden>Choose City</option>
                                @foreach ($cities as $city)
                                    <option value="{{ $city->id }}">{{ $city->name }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-12 form-group">
                            <label class="form-label" for="ch-address">Street address<sup class="text-danger ml-1">*</sup></label>
                            <input class="form-control" type="text" id="ch-address"
                                placeholder="House number and street name" required>
                        </div>
                        <div class="col-12 form-group">
                            <input class="form-control" type="text" id="ch-floor" placeholder="Apartment, suite, unit, etc. (optional)">
                        </div>
                        <div class="col-12 form-group">
                            <label class="form-label" for="ch-delivery">Delivery Type<sup class="text-danger ml-1">*</sup></label>
                            <select class="form-control custom-select" id="ch-delivery" required>
                                <option value="" selected disabled hidden>Choose Delivery Service</option>
                                <option value="">Home Delivery</option>
                                <option value="">Take Away</option>
                            </select>
                        </div>
                        <div class="col-12 form-group">
                          <!-- Date and time picker -->
                          <div class="form-group">
                            <label class="form-label">Choose date and time<sup class="text-danger ml-1">*</sup></label>
                            <div class="input-group-overlay">
                              <input class="form-control appended-form-control cs-date-picker" type="text" placeholder="Choose date and time"  id="ch-time" required 
                              data-datepicker-options='{"enableTime": true, "altInput": true, "altFormat": "F j, Y H:i", "dateFormat": "Y-m-d H:i"}'>
                              <div class="input-group-append-overlay">
                                <span class="input-group-text">
                                  <i class="fe-calendar"></i>
                                </span>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div class="col-12 form-group">
                            <label class="form-label" for="ch-postcode">Postcode<sup class="text-danger ml-1">*</sup></label>
                            <select class="form-control custom-select chosen" id="ch-postcode" required>
                            </select>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form-label" for="ch-phone">Phone<sup class="text-danger ml-1">*</sup></label>
                            <input class="form-control" type="tel" id="ch-phone" required>
                        </div>
                        <div class="col-sm-6 form-group">
                            <label class="form-label" for="ch-email">Email address<sup
                                    class="text-danger ml-1">*</sup></label>
                            <input class="form-control" type="email" id="ch-email" required>
                        </div>
                    </div>
                    <h2 class="h3 pb-3">Additional information</h2>
                    <div class="form-group pb-3 pb-lg-5">
                        <label class="form-label" for="ch-order-notes">Order notes</label>
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <span class="input-group-text">
                                    <i class="fe-message-square"></i>
                                </span>
                            </div>
                            <textarea class="form-control" id="ch-order-notes" rows="5"
                                placeholder="Notes about your order, e.g. special notes for delivery."></textarea>
                        </div>
                    </div>
                </div>
                <!-- Sidebar-->
                <div class="col-lg-4 cs-sidebar bg-secondary pt-5 pl-lg-4 pb-md-2">
                    <div class="pl-lg-4 mb-3 pb-5">
                        <h2 class="h4 pb-3">Your cart (<span id="cartItemsCounter">{{ Cart::cartItems() }}</span>)</h2>

                        <div id="cartBody">
                            @include('main.components.cartItems')
                        </div>

                        <hr class="mb-4">
                        {{-- <div class="d-flex justify-content-between mb-3"><span
                                class="h6 mb-0">Subtotal:</span><span class="text-nav"> {{ Cart::totalPrice() }} CHF</span>
                        </div> --}}
                        <div class="d-flex justify-content-between mb-3"><span class="h6 mb-0">Tax:</span><span
                                class="text-nav">&mdash;</span></div>
                        <div class="d-flex justify-content-between mb-3"><span class="h6 mb-0">Shipping:</span><span
                                class="text-nav">&mdash;</span></div>
                        <div class="d-flex justify-content-between mb-3"><span class="h6 mb-0">Total:</span><span
                                class="h6 mb-0" id="totalPrice"> {{ Cart::totalPrice() }} CHF</span></div>
                        <div class="accordion accordion-alt pt-4 mb-grid-gutter" id="payment-methods">
                            <div class="card border-0 box-shadow card-active">
                                <div class="card-header p-3">
                                    <div class="p-1">
                                        <div class="custom-control custom-radio" data-toggle="collapse"
                                            data-target="#credit-card">
                                            <input class="custom-control-input" type="radio" id="credit-card-radio"
                                                name="payment_method" checked required>
                                            <label class="custom-control-label d-flex align-items-center h6 mb-0"
                                                for="credit-card-radio"><span>Credit Card</span><img class="ml-3"
                                                    width="130" src="{{ asset('image/cards.png') }}" alt="Accepted cards" />
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse show" id="credit-card" data-parent="#payment-methods">
                                    <div class="card-body">
                                        <div class="form-group">
                                            <label class="form-label" for="cc-number">Card number</label>
                                            <input class="form-control bg-image-0" type="text" id="cc-number"
                                                data-format="card" placeholder="0000 0000 0000 0000">
                                        </div>
                                        <div class="row no-gutters">
                                            <div class="col-7 px-2 form-group mb-1">
                                                <label class="form-label" for="cc-expiry">Expiry date</label>
                                                <input class="form-control bg-image-0" type="text" id="cc-expiry"
                                                    data-format="date" placeholder="mm/yy">
                                            </div>
                                            <div class="col-5 px-2 form-group mb-1">
                                                <label class="form-label" for="cc-cvc">CVC</label>
                                                <input class="form-control bg-image-0" type="text" id="cc-cvc"
                                                    data-format="cvc" placeholder="000">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card border-0 box-shadow">
                                <div class="card-header p-3">
                                    <div class="p-1">
                                        <div class="custom-control custom-radio collapsed" data-toggle="collapse"
                                            data-target="#paypal">
                                            <input class="custom-control-input" type="radio" id="paypal-radio" name="payment_method" required>
                                            <label class="custom-control-label d-flex align-items-center h6 mb-0"
                                                for="paypal-radio"><span>PayPal</span><img class="ml-3" width="20"
                                                    src="{{ asset('image/paypal.png') }}" alt="PayPal" />
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse" id="paypal" data-parent="#payment-methods">
                                    <div class="card-body">
                                        <p class="font-size-ms">By clicking on the button below you will be redirected to
                                            your PayPal account to complete the payment.</p><a class="d-inline-block"
                                            href="#"><img class="d-block" width="200"
                                                src="{{ asset('image/paypal-button.png') }}" alt="PayPal" /></a>
                                    </div>
                                </div>
                            </div>
                            <div class="card border-0 box-shadow">
                                <div class="card-header p-3">
                                    <div class="p-1">
                                        <div class="custom-control custom-radio collapsed" data-toggle="collapse" data-target="#cash">
                                            <input class="custom-control-input" type="radio" id="cash-radio" name="payment_method" required>
                                            <label class="custom-control-label d-flex h6 mb-0" for="cash-radio">Cash on delivery</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="collapse" id="cash" data-parent="#payment-methods">
                                    <div class="card-body">
                                        <p class="font-size-ms mb-0">You have selected to pay with cash upon delivery.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="btn btn-primary btn-block" type="submit">Place order</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection

@section('customJs')
  <script src="{{ asset('js/chosen.jquery.js') }}"></script>
  <script src="{{ asset('js/flatpickr.min.js') }}"></script>
  <script>
    $(document).ready(function() {
        $('#ch-time').flatpickr({
          enableTime: true,
          time_24hr: true
        });
    });
</script>
@endsection
