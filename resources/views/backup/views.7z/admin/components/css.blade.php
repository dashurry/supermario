<!-- General CSS Files -->
<link rel="stylesheet" href="{{ asset('admin_area/assets/css/app.min.css') }}">
<link rel="stylesheet" href="{{ asset('admin_area/assets/bundles/izitoast/css/iziToast.min.css') }}">
  <!-- Template CSS -->
  <link rel="stylesheet" href="{{ asset('admin_area/assets/css/style.css') }}">
  <link rel="stylesheet" href="{{ asset('admin_area/assets/css/components.css') }}">
  <!-- Custom style CSS -->
  <link rel="stylesheet" href="{{ asset('admin_area/assets/css/custom.css') }}">
  <link rel='shortcut icon' type='image/x-icon' href='{{ asset('admin_area/assets/img/favicon.ico') }}' />