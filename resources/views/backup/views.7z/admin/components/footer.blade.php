<footer class="main-footer">
        <div class="footer-left">
          <a href="templateshub.net">© Super Mario Ristorante</a></a>
        </div>
        <div class="footer-right">
        </div>
      </footer>